# Rasluck Furniture Enterprises – Complete Website Development Prompt

**Project Overview**  
Act as a senior web designer, frontend developer, UI/UX strategist, and SEO expert with 16+ years of experience building premium, high-conversion websites for Nigerian businesses in the furniture, interior design, and home solutions sector.

Build a complete, production-ready, luxurious website for:

- **Business Name**: Rasluck Furniture Enterprises  
- **Phone**: 09023386969  
- **Email**: Raasluckintegratedservices@gmail.com  
- **Location**: Nigeria (Lagos-based, serving nationwide)

**Business Focus**  
Primary: Furniture design, custom manufacturing, and sales.  
Secondary: Home appliances and professional solar installation services.

**Website Goal**  
The website must serve as the primary sales engine. Every page and interaction must drive conversions into WhatsApp chats, phone calls, quote requests, and direct purchases. The design must feel premium, trustworthy, and luxurious while remaining simple and accessible to all age groups.

**Brand Style Requirements**  
- Luxurious, clean, modern, and highly professional  
- Visually striking yet elegant furniture presentation  
- Mobile-first, fast-loading, and fully SEO-optimized  
- Stand out in Google search results for furniture-related queries in Nigeria  
- No emojis anywhere in the UI, copy, buttons, headings, or footer  
- Subtle, sophisticated animations only (use AOS.js for scroll-triggered effects)

**Color Palette**  
- Primary: Bark Blue (#1E2A44 or closest premium shade)  
- Secondary: Light Blue (#A5C4E0 or refined elegant tone)  
- Neutral: White (#FFFFFF) with subtle off-white accents for depth

**Technical Stack (Strict Requirements)**  
- Tailwind CSS (via Play CDN or properly configured build)  
- Vanilla JavaScript + AOS.js (Animate On Scroll) for lightweight, performant scroll animations  
- Font Awesome (latest CDN version) for icons  
- Google Fonts via official CDN only  
- Only essential external libraries where genuinely required (after research, AOS.js is approved for its excellent performance/size ratio on static luxury sites; no heavy frameworks or unnecessary dependencies)  
- Clean, semantic HTML5  
- Fully responsive (mobile, tablet, desktop)  
- Production-ready, well-organized, and commented code

**Image Assets**  
All design images are organised in the folder: `Office_Design_images` with the following categories (use these exact paths in the code):  
- Bar Space Design  
- Bedframe Design  
- Chair Design  
- Kitchen Design  
- Mirror Design (correct spelling)  
- Office Design  
- Toilet Design  
- Tv Console  
- Wardrobe (correct spelling from “Waldrop”)  

The Furniture Gallery must be the visual centrepiece of the website.  
- Bedframe/Bedroom designs: minimum 30 image cards/placements  
- Sitting room/Chair designs: minimum 20 image cards/placements  
- Kitchen designs: minimum 25 image cards/placements  
- Office, Toilet/Bathroom, Bar Space, TV Console, Mirror, and Wardrobe categories must also be prominently featured with elegant presentation.

**Required Pages & SEO Elements**  
- Proper meta tags, title tags, Open Graph, Twitter Cards, and canonical tags on every page  
- robots.txt and sitemap.xml content  
- Schema markup (LocalBusiness + Product + FAQ + BreadcrumbList)  
- Strategic internal linking and local SEO optimised for Nigerian search intent  
- Image alt text strategy focused on SEO and accessibility

**Content & Conversion Focus**  
- Simple, premium, persuasive language tailored to Nigerian buyers  
- Strong trust signals and social proof elements  
- Multiple, prominent WhatsApp-focused CTAs  
- One-stop home solution positioning (furniture + appliances + solar)

**Deliverables Required**  
Create a complete website blueprint and implementation plan with the following sections clearly labelled:

1. Short Strategy Summary  
2. Suggested Sitemap & Navigation  
3. Homepage – section-by-section wireframe and full copy  
4. Supporting page content (About, Services, Furniture Gallery, Home Appliances, Solar Installation, Contact)  
5. SEO Recommendations (including title & meta description ideas for every page)  
6. Design & UI Recommendations (luxurious direction using the exact color palette)  
7. Technical Implementation Recommendations (Tailwind + AOS.js + Font Awesome setup)  
8. CTA Variations (WhatsApp-focused)  
9. FAQ Section Copy  
10. Footer & Contact Details  
11. Meta Tags, sitemap.xml, robots.txt, and Schema Guidance  

**Important Guidelines**  
- Keep copy concise, confident, and professional – never wordy.  
- Make the brand feel strong, memorable, and premium.  
- Prioritise performance (Core Web Vitals), accessibility (WCAG 2.2 AA), and mobile experience.  
- Ensure the site looks and feels luxurious while loading fast even on Nigerian networks.  
- All animations must be subtle, elegant, and performance-optimised.  

Use this prompt to generate the full, ready-to-deploy website code structure and content.